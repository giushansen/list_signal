# ListSignal brand rollout — instructions for Claude Code

You are working in the ListSignal repo (Elixir / Phoenix / LiveView, Tailwind 3.4). Two jobs, end to end, autonomously:

1. Replace the placeholder `LS` letter box with the real ListSignal mark everywhere it belongs, internal and external.
2. Write `docs/brand/README.md`: the brand and design doc (logo, colours, type, Tailwind tokens, component conventions, copy rules), written **from the code**, so nothing drifts again.

Read the whole file before touching anything. Where this file and the repo disagree, the repo wins for facts (paths, token values) and this file wins for intent.

---

## 1. What the mark is

"Live list": three horizontal lines of equal length and equal stroke; the middle one carries a heartbeat. Three records, one live signal.

Geometry, 64-unit grid, stroke 7, round caps and joins, one stroke weight everywhere:

```
M10 11H54 M10 32H23L28 23L36 41L41 32H54 M10 53H54
```

That path **is** the logo. It is frozen. Do not redraw, restyle, gradient, shadow, glow, outline, rotate or animate it. Colour comes from `currentColor` inline, or from the pre-rendered variants in the pack.

Reference image: `docs/brand/preview.png` (three colourways, lockups, true-pixel favicons).

---

## 2. The asset pack

`brand-pack/` sits at the repo root. It mirrors the repo layout and only **adds or replaces** files:

```
brand-pack/priv/static/images/brand/
  mark.svg                      inline/CSS-coloured (stroke="currentColor")
  mark-{white,black,green}.svg  fixed-colour, transparent background
  mark-{white,black,green}-512.png
  tile-{green,black,white}.svg  rounded square + mark: white-on-green (primary), white-on-dark, dark-on-white
  tile-green-{256,512,1024}.png tile-black-512.png tile-white-512.png
  lockup-on-{dark,light}.svg    tile + "ListSignal" wordmark (Sora Bold)
  lockup-on-{dark,light}.png    + -2x.png   raster twins, real font, transparent

brand-pack/priv/static/
  favicon.ico (16/32/48)  favicon.svg  favicon-16x16.png  favicon-32x32.png
  apple-touch-icon.png (180)  icon-192.png  icon-512.png  site.webmanifest
  og-card.png (1200x630)

brand-pack/docs/brand/
  gen_brand_assets.py           regenerates every file above from the path and two colours
  preview.png
```

Install: `cp -R brand-pack/priv brand-pack/docs . && rm -rf brand-pack`. The existing `favicon.ico`, `favicon-32x32.png`, `apple-touch-icon.png` and `og-card.png` are meant to be overwritten.

Colours baked into the raster files: accent `#10b981`, dark `#0a0e17`. Verify them in §4 step 1 before installing.

---

## 3. Hard rules

1. **Geometry is frozen.** Never hand-edit anything under `priv/static/images/brand/` or the favicons. To change a colour, edit the two constants at the top of `docs/brand/gen_brand_assets.py` and regenerate.
2. **Tokens come from the repo.** Read `assets/tailwind.config.js` and `assets/css/app.css`. Never invent a colour, font, radius or size. If a value is not in the config, the doc says "not a token, hard-coded in <file>" rather than inventing one.
3. **Emails get no logo.** `test/ls/engagement_test.exs` asserts that a founder's note has no `<img>`. That is deliberate. Do not touch `lib/ls/email_layout.ex` or any email body.
4. **Cold-email signatures stay plain text.** Out of scope. Do not create a signature asset.
5. **No unsourced claims in the doc.** Every rule in `docs/brand/README.md` points at the file, test or config that enforces it.
6. **Public nav stays single-source-of-truth** (see the `@doc` on `public_nav/1` in `lib/ls_web/components/layouts.ex`). No per-page headers. The per-page `<footer>` blocks in `lib/ls_web/controllers/tech_html/show.html.heex` and `store_html/show.html.heex` are **not** to be refactored in this task; report them as a follow-up.
7. **Minimal diff.** No drive-by refactors, no new dependencies, no migration of the dashboard's inline CSS to Tailwind.
8. **Do not push. Do not deploy.** Commit locally in three commits: `brand: assets`, `brand: components and rollout`, `docs: brand and design guide`.

---

## 4. Read first (do not skip)

1. `assets/tailwind.config.js` + `assets/css/app.css`. Confirm `accent` is `#10b981` and `ls-dark` is `#0a0e17`. If either differs: change `ACCENT` / `DARK` in `docs/brand/gen_brand_assets.py`, then

   ```
   pip install cairosvg pillow
   python3 docs/brand/gen_brand_assets.py --out /tmp/bp && cp -R /tmp/bp/priv /tmp/bp/docs .
   ```

   (the script fetches Sora and DM Sans from github.com/google/fonts; it tells you if it had to fall back). If Python/cairo is unavailable, **stop and report the real values**; do not ship mismatched colours.
2. `lib/ls_web.ex` → `static_paths/0`. Today: `~w(assets fonts images favicon.ico favicon-32x32.png apple-touch-icon.png og-card.png robots.txt llms.txt verify.html)`.
3. `lib/ls_web/components/layouts.ex`: `public_root/1`, `root/1`, `app/1`, `public_nav/1`, `footer/1`.
4. `lib/ls_web/live/dashboard_live.ex` (header block, inline CSS, JetBrains Mono), `lib/ls_web/live/explorer_live.ex` (header with plan badges), every auth / settings / error layout you can find.
5. Inventory the placeholder and every brand touchpoint, and paste the output in the final report:

   ```
   grep -rn --include='*.ex' --include='*.heex' --include='*.html' --include='*.md' --include='*.json' \
     -E '>\s*LS\s*<|LS</span>|font-extrabold|from-white/20|favicon|og-card|og:image|twitter:image|apple-touch-icon|manifest|theme-color' \
     lib priv docs README.md
   ```

---

## 5. Brand components (one module, imported everywhere)

Create `lib/ls_web/components/brand_components.ex` → `LSWeb.BrandComponents`, `use Phoenix.Component`.

- `logo_mark/1`: inline `<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round" stroke-linejoin="round">` with the frozen path. Attrs: `size` (integer, default 24, sets `width`/`height`), `class`, `label` (string, default `nil`). With no label: `aria-hidden="true"`. With a label: `role="img"` and a `<title>` element. Inline on purpose: takes `currentColor`, costs no request.
- `logo_tile/1`: the rounded square. Default matches today's nav box: `flex h-[30px] w-[30px] items-center justify-center rounded-lg bg-accent text-white` wrapping `<.logo_mark size={20} />`. Attr `size` scales box and mark together (mark = 0.66 × box). **Drop the gradient overlay** (`bg-gradient-to-br from-white/20 to-transparent`) that the old LS box carried; nothing in the brand has gradients.
- `logo_lockup/1`: `<a href={@href}>` with `logo_tile` + the wordmark `ListSignal` in `font-display font-bold tracking-tight`. Attrs: `href` (default `"/"`), `text_class` (default `text-[21px]`, i.e. today's nav), `class`. Keep the `gap-2`.

Add `import LSWeb.BrandComponents` to `html_helpers/0` in `lib/ls_web.ex` so every template and LiveView sees it.

---

## 6. Rollout checklist (tick each in the report; write "n/a, because…" where it does not apply)

### Internal, in the repo

- [ ] `public_nav/1`: the `LS` span becomes `<.logo_lockup />`. Anchor, gap and text size unchanged.
- [ ] `footer/1`: a muted mark beside the copyright line (`<.logo_mark size={18} class="text-white/35" />`). Links untouched.
- [ ] `public_root/1` `<head>`:
  - keep `og:image` and `twitter:image` at `https://listsignal.com/og-card.png` (the file is replaced); add `og:image:width` 1200, `og:image:height` 630, `og:image:alt` "ListSignal".
  - favicons, in this order: `<link rel="icon" href="/favicon.svg" type="image/svg+xml">`, the existing 32x32 PNG, `<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">`, the `.ico`, the apple-touch-icon; then `<link rel="manifest" href="/site.webmanifest">` and `<meta name="theme-color" content="#0a0e17">`.
  - extract that block into a private `head_icons/1` component used by **both** `public_root/1` and `root/1`, so the two layouts cannot drift.
- [ ] `root/1` (dashboard/app layout) `<head>`: uses `head_icons/1`.
- [ ] `lib/ls_web.ex` `static_paths/0`: add `favicon.svg favicon-16x16.png icon-192.png icon-512.png site.webmanifest`. Without this, Plug.Static will 404 them.
- [ ] `dashboard_live.ex` header: `<.logo_mark size={20} class="…" />` before the `h1`, colour `#e8edf4` (the h1 colour), via the inline-CSS style that file already uses. No other changes to that file.
- [ ] `explorer_live.ex` header: if it renders a brand/title, replace with `<.logo_lockup text_class="text-base" />`; if the surrounding layout already shows one, leave it and say which.
- [ ] Auth pages (`/users/log-in`, `/signup`, magic-link confirmation, `/users/settings`): use `logo_lockup` wherever a brand is rendered today. If none is, add a centred `logo_lockup` above the form on log-in and signup only.
- [ ] Error pages (`LSWeb.ErrorHTML`): only if they render a layout; otherwise skip.
- [ ] `/developers` page: brand via the component if the page shows one. If `/openapi.json` has an `info` map, add `"x-logo": {"url": "https://listsignal.com/images/brand/tile-green-512.png", "altText": "ListSignal"}` (Redoc convention). Do **not** invent an MCP icon field unless the MCP server code already supports one.
- [ ] `README.md`: under the title, `<img src="priv/static/images/brand/tile-green-256.png" width="64" alt="ListSignal">` (works on GitHub light and dark), and one line: `Brand and design rules: docs/brand/README.md`.
- [ ] `CLAUDE.md` (if present): the same one-line pointer, so future sessions read the doc before touching layouts, colours or the logo.

### External, manual (you cannot do these: list them in the report with the exact file)

- Stripe → Settings → Branding: icon `tile-green-512.png`, logo `lockup-on-light-2x.png`, accent `#10b981`.
- GitHub repo → Settings → Social preview: `og-card.png`.
- Google Workspace / Gmail avatar for will@listsignal.com: `tile-green-512.png`.
- LinkedIn, X, Product Hunt, Crunchbase: avatar `tile-green-1024.png`, banner `og-card.png`.
- MCP registry submissions (`docs/api-and-mcp.md` playbook): `tile-green-512.png` wherever a logo is requested.
- Instantly: nothing. Signatures stay plain text.

---

## 7. `docs/brand/README.md` — the design doc

Written from the code, every claim with a path. Sections, in order:

1. **Identity.** "ListSignal" is one word, capital L and S, never "List Signal" or "LS" in prose. One-line description: use the site's own `<title>` line from `public_root/1`. Tone: evidence-first; cite the places that enforce it (the "no unsourced stats" and "ugly beats wrong" comments and tests, e.g. `test/ls/engagement_test.exs`, the Umami notes in `README.md`).
2. **Logo.** Construction (grid, stroke, the path), meaning, the three colourways and when each is used (white-on-green primary; white-on-dark on `ls-dark` surfaces; dark-on-white on light surfaces and print), minimum sizes (tile ≥ 16 px, inline mark ≥ 14 px), clear space = one stroke width (7/64 of the mark) on all sides, and the don'ts: no gradient, shadow, glow, outline, rotation or animation; no recolouring outside the three colourways; no letters added to or around the mark; never the bare mark on accent green without the tile. A usage table: surface → component or file.
3. **Colour.** Copy the real `theme.extend.colors` from `assets/tailwind.config.js` as a table (token → hex → where used, with file paths). List the dashboard's inline palette from `dashboard_live.ex` (`#0a0e17` background, `#111827` cards, `#1e293b` borders, `#38bdf8` dashboard accent, `#4ade80` / `#fbbf24` / `#f87171` status) and label it "dashboard-only, inline CSS, not Tailwind tokens". Compute and state WCAG contrast: white on `#10b981` is about 2.5:1 (fails AA for text: fine for the mark, and it is also the pair used on the primary CTA — record the number, do not change the CTA); white on `#0a0e17` is about 19:1. Recompute rather than trusting these figures.
4. **Typography.** Sora = `font-display` (wordmark: 21 px / 700 / `tracking-tight` in the nav; headings), DM Sans = `font-body`, JetBrains Mono + IBM Plex Sans = dashboard only. Weights actually loaded (from the Google Fonts `<link>` in `public_root/1`) and sizes actually used in the codebase.
5. **Layout and components.** Container `max-w-[1200px] px-6`; fixed nav `bg-ls-dark/85 backdrop-blur-xl border-white/[0.07]`; radii in use (`rounded-lg` tiles and nav buttons, `rounded-xl` large CTAs, `rounded-full` chips); primary and secondary CTA class strings; the plan-badge chips in `explorer_live.ex`; the `text-white/60 → hover:text-white` link convention; the animated `Live Feed` dot on the home page. Real class strings, copied.
6. **Copy rules.** From the code comments and tests: emails are founder notes (paragraphs, no images, no tables, one accent link); search descriptions never misrepresent the search; no fabricated statistics or social proof anywhere. Link, don't paraphrase at length.
7. **Assets.** Inventory table (path → size → use). How to regenerate (`docs/brand/gen_brand_assets.py`, its two constants, its dependencies). The rule that everything under `images/brand/` and the favicons are derived files, never edited by hand.
8. **Where the logo lives.** The completed checklist from §6, with file paths, plus the manual external list.
9. **Changelog.** `2026-09-07 v1: replaced the LS letter box with the Live list mark.`

Style of the doc: sentence case, no all-caps labels, no marketing language, tables where they help, under ~300 lines.

---

## 8. Verify before you report

- `mix compile --warnings-as-errors`, `mix format --check-formatted`, `mix test`: all green. Fix, don't skip, any nav/layout test that breaks.
- `grep -rn 'from-white/20' lib` returns nothing. The §4.5 inventory grep no longer matches the placeholder box anywhere.
- Run the server. Each of these returns 200 with the right content type: `/favicon.svg /favicon.ico /favicon-16x16.png /favicon-32x32.png /apple-touch-icon.png /icon-192.png /icon-512.png /site.webmanifest /og-card.png /images/brand/mark.svg /images/brand/tile-green-512.png`.
- `curl` these pages: `/`, `/pricing`, `/features`, `/developers`, `/apps`, `/users/log-in`, `/signup`, one `/store/…` page, one tech page. Each contains an `<svg` with `viewBox="0 0 64 64"` inside the nav, exactly one `rel="manifest"`, one `theme-color`, and `og:image` pointing at `https://listsignal.com/og-card.png`.
- Dashboard route, logged in as the seed admin from `README.md`: the mark renders in the header.

## 9. Report

Files changed; the §6 checklist with ticks and n/a reasons; the inventory grep before and after; the manual external list; anything skipped and why. If you were unsure about anything, say so rather than guess.
